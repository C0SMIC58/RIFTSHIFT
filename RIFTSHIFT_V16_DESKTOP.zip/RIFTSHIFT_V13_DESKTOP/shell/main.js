const { app, BrowserWindow, Menu, ipcMain } = require("electron");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const SHELL_VERSION = "16.0.0";
let mainWindow = null;

function rootDir(){
  return path.resolve(path.dirname(process.execPath), "..");
}
function gameDir(){
  return path.join(rootDir(), "game");
}
function gamePath(){
  return path.join(gameDir(), "index.html");
}
function configPath(){
  return path.join(rootDir(), "update-config.json");
}
function installedVersion(){
  try{return fs.readFileSync(path.join(gameDir(),"version.txt"),"utf8").trim()||"0.0.0";}
  catch{return "0.0.0";}
}
function versionParts(v){
  return String(v||"0").replace(/^v/i,"").split(".").map(n=>parseInt(n,10)||0);
}
function newer(a,b){
  const A=versionParts(a),B=versionParts(b);
  for(let i=0;i<Math.max(A.length,B.length);i++){
    const x=A[i]||0,y=B[i]||0;
    if(x!==y)return x>y;
  }
  return false;
}
function readConfig(){
  const fallback={manifestUrl:"https://raw.githubusercontent.com/C0SMIC58/RIFTSHIFT/main/update.json"};
  try{
    const parsed=JSON.parse(fs.readFileSync(configPath(),"utf8"));
    if(!String(parsed.manifestUrl||"").trim())return fallback;
    return parsed;
  }catch{
    return fallback;
  }
}
async function downloadBuffer(url){
  const r=await fetch(url,{cache:"no-store"});
  if(!r.ok)throw new Error(`HTTP ${r.status} ${r.statusText}`);
  return Buffer.from(await r.arrayBuffer());
}
async function getManifest(){
  const cfg=readConfig();
  const url=String(cfg.manifestUrl||"").trim();
  if(!url)return {ok:false,reason:"not-configured"};
  const raw=await downloadBuffer(url);
  const manifest=JSON.parse(raw.toString("utf8"));
  if(!manifest.version||!manifest.gameUrl)throw new Error("Manifest needs version and gameUrl.");
  return {ok:true,manifest,url};
}
async function checkUpdate(){
  try{
    const result=await getManifest();
    if(!result.ok)return result;
    const m=result.manifest;
    return {
      ok:true,
      available:newer(m.version,installedVersion()),
      installedVersion:installedVersion(),
      version:String(m.version),
      gameUrl:String(m.gameUrl),
      sha256:String(m.sha256||"").toLowerCase(),
      notes:String(m.notes||"")
    };
  }catch(err){
    return {ok:false,reason:"error",message:err.message};
  }
}
async function installUpdate(info){
  try{
    if(!info||!info.gameUrl||!info.version)throw new Error("Update information is incomplete.");
    if(!newer(info.version,installedVersion()))return {ok:false,message:"That update is not newer than the installed game."};

    const data=await downloadBuffer(info.gameUrl);
    if(info.sha256){
      const hash=crypto.createHash("sha256").update(data).digest("hex").toLowerCase();
      if(hash!==String(info.sha256).toLowerCase())throw new Error("SHA-256 verification failed.");
    }

    fs.mkdirSync(gameDir(),{recursive:true});
    const tmp=path.join(gameDir(),"index.html.update");
    const backup=path.join(gameDir(),"index.html.previous");
    fs.writeFileSync(tmp,data);
    try{if(fs.existsSync(backup))fs.unlinkSync(backup);}catch{}
    try{if(fs.existsSync(gamePath()))fs.renameSync(gamePath(),backup);}catch{}
    fs.renameSync(tmp,gamePath());
    fs.writeFileSync(path.join(gameDir(),"version.txt"),String(info.version)+"\n");
    const nowInstalled=installedVersion();

    setTimeout(()=>{
      app.relaunch();
      app.exit(0);
    },500);
    return {ok:true,installedVersion:nowInstalled};
  }catch(err){
    return {ok:false,message:err.message};
  }
}

ipcMain.handle("riftshift:update-check",()=>checkUpdate());
ipcMain.handle("riftshift:update-install",(_event,info)=>installUpdate(info));

function createWindow(){
  Menu.setApplicationMenu(null);
  if(!fs.existsSync(gamePath()))throw new Error("RIFTSHIFT game files are missing: "+gamePath());

  mainWindow=new BrowserWindow({
    title:"RIFTSHIFT",
    width:1440,
    height:900,
    minWidth:960,
    minHeight:620,
    backgroundColor:"#05070d",
    autoHideMenuBar:true,
    fullscreen:true,
    show:false,
    icon:path.join(__dirname,"RIFTSHIFT.ico"),
    webPreferences:{
      preload:path.join(__dirname,"preload.js"),
      contextIsolation:true,
      nodeIntegration:false,
      sandbox:false,
      backgroundThrottling:false
    }
  });

  mainWindow.loadFile(gamePath());
  mainWindow.once("ready-to-show",()=>{
    mainWindow.setFullScreen(true);
    mainWindow.show();
    mainWindow.focus();
  });

  mainWindow.webContents.on("before-input-event",(event,input)=>{
    if(input.type==="keyDown"&&input.key==="F11"){
      event.preventDefault();
      mainWindow.setFullScreen(!mainWindow.isFullScreen());
    }
  });
}

app.whenReady().then(createWindow);
app.on("activate",()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});
app.on("window-all-closed",()=>{if(process.platform!=="darwin")app.quit();});
