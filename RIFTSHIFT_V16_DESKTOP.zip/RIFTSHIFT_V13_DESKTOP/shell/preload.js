const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("riftshiftUpdater", {
  check: () => ipcRenderer.invoke("riftshift:update-check"),
  install: (info) => ipcRenderer.invoke("riftshift:update-install", info)
});
