RIFTSHIFT V16 — BOSS / ENCOUNTER UPDATE

BOSSES
- Higher baseline durability and pressure.
- All four bosses gained new mechanics.
- Every boss enters RAGE below 15% HP.
- Wave 20+ bosses can gain one modifier.
- Wave 35+ bosses can gain two modifiers.
- Modifiers: Frenzied, Armored, Mirrored, Vampiric, Overloaded.

RIFT WARDEN
- Rotating laser arrays.
- Denser radial barrages with moving safe gaps.
- Phase II+ buff pylons that reduce incoming damage until destroyed.

VOID DEVOURER
- Vacuum pull toward the boss.
- Close-range bite blast.
- Persistent void pools that restrict movement.
- More minion pressure.

NULL ARTILLERY
- Targeted mortar warning zones.
- Deployable firing turrets.
- Denser cannon spreads and radial barrages.

PHASE SPECTER
- False clones that independently fire at the player.
- More aggressive teleport attacks.
- Rage creates a large clone swarm.

MINI-BOSSES
- Rift Knight
- Siege Walker
- Arc Sentinel
- Mimic Core
Selected non-boss waves now contain mini-boss encounters. Defeating one grants extra Scrap, a reroll, and a guaranteed Epic upgrade token.

RIFT CONTRACTS
Optional challenge offers can appear on eligible waves:
- Groundlock
- Hostile Overclock
- Glass Circuit
- Redline Quota
Successful contracts award Scrap, rerolls, or guaranteed Epic rarity.

RARE ARENA EVENTS
- Blackout Protocol
- Rift Storm
- Redline Breach
These alter visibility, hazards, or enemy pressure and give bonus Scrap if survived.
