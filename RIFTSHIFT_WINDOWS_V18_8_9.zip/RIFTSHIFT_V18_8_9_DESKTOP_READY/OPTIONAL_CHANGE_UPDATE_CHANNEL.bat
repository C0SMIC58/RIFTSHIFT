@echo off
setlocal
title RIFTSHIFT Update Channel
color 0B
set "ROOT=%LOCALAPPDATA%\RIFTSHIFT"
if not exist "%ROOT%" (
  echo RIFTSHIFT is not installed yet.
  pause
  exit /b 1
)
echo.
echo Paste the PUBLIC direct URL to your update.json manifest.
echo Example:
echo https://raw.githubusercontent.com/YOURNAME/RIFTSHIFT/main/update.json
echo.
set /p "URL=Manifest URL: "
if "%URL%"=="" (
  echo No URL entered.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
 "$o=@{manifestUrl='%URL%'}; $o | ConvertTo-Json | Set-Content -Encoding UTF8 '%ROOT%\update-config.json'"
echo.
echo Update channel saved.
echo The RIFTSHIFT main menu can now check that URL for updates.
pause
