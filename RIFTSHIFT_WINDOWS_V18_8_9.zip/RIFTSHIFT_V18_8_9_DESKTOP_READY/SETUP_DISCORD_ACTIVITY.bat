@echo off
setlocal EnableExtensions
title RIFTSHIFT Discord Activity Setup
color 0B
cd /d "%~dp0"

echo.
echo =============================================
echo       RIFTSHIFT DISCORD GAME ACTIVITY
echo =============================================
echo.
set /p APPID=Paste your Discord Application ID: 
if "%APPID%"=="" goto :bad

set /p LARGE=Optional Rich Presence large image key (press Enter to skip): 

> "%~dp0discord-config.json" echo {
>> "%~dp0discord-config.json" echo   "applicationId": "%APPID%",
>> "%~dp0discord-config.json" echo   "enabled": true,
>> "%~dp0discord-config.json" echo   "largeImageKey": "%LARGE%",
>> "%~dp0discord-config.json" echo   "largeImageText": "RIFTSHIFT",
>> "%~dp0discord-config.json" echo   "smallImageKey": "",
>> "%~dp0discord-config.json" echo   "smallImageText": ""
>> "%~dp0discord-config.json" echo }

if exist "%LOCALAPPDATA%\RIFTSHIFT" (
  copy /Y "%~dp0discord-config.json" "%LOCALAPPDATA%\RIFTSHIFT\discord-config.json" >nul
  echo Updated installed RIFTSHIFT config.
)

echo.
echo Discord Rich Presence configuration saved.
echo Restart RIFTSHIFT with Discord Desktop open.
echo.
pause
exit /b 0

:bad
echo No Application ID entered.
pause
exit /b 1
