@echo off
setlocal EnableExtensions
title RIFTSHIFT V18.8.9 Installer
color 0B
cd /d "%~dp0"

set "ROOT=%LOCALAPPDATA%\RIFTSHIFT"
set "RUNTIME=%ROOT%\runtime"
set "GAME=%ROOT%\game"
set "SHELL=%RUNTIME%\resources\app"
set "ZIP=%TEMP%\riftshift-electron.zip"
set "VERSION=43.4.1"

echo.
echo ==========================================
echo        RIFTSHIFT V18.8.9 DESKTOP INSTALL
echo ==========================================
echo.

if not exist "%ROOT%" mkdir "%ROOT%"
if not exist "%GAME%" mkdir "%GAME%"

echo [1/5] Copying V18 game...
xcopy "%~dp0game" "%GAME%\" /E /I /Y >nul

copy /Y "%~dp0update-config.json" "%ROOT%\update-config.json" >nul
if not exist "%ROOT%\discord-config.json" copy /Y "%~dp0discord-config.json" "%ROOT%\discord-config.json" >nul

if exist "%RUNTIME%\RIFTSHIFT.exe" goto :runtime_ready

echo [2/5] Downloading Electron runtime once...
if exist "%ZIP%" del /f /q "%ZIP%" >nul 2>nul
where curl.exe >nul 2>nul
if errorlevel 1 goto :psdownload

curl.exe -fL --retry 3 --connect-timeout 20 ^
"https://github.com/electron/electron/releases/download/v%VERSION%/electron-v%VERSION%-win32-x64.zip" ^
-o "%ZIP%"
if not errorlevel 1 goto :downloaded

curl.exe -fL --retry 2 --connect-timeout 20 ^
"https://npmmirror.com/mirrors/electron/%VERSION%/electron-v%VERSION%-win32-x64.zip" ^
-o "%ZIP%"
if not errorlevel 1 goto :downloaded
goto :download_failed

:psdownload
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
"$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/electron/electron/releases/download/v%VERSION%/electron-v%VERSION%-win32-x64.zip' -OutFile '%ZIP%'"
if errorlevel 1 goto :download_failed

:downloaded
echo [3/5] Extracting runtime...
if exist "%RUNTIME%" rmdir /s /q "%RUNTIME%"
mkdir "%RUNTIME%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%RUNTIME%' -Force"
if not exist "%RUNTIME%\electron.exe" goto :extract_failed
move /Y "%RUNTIME%\electron.exe" "%RUNTIME%\RIFTSHIFT.exe" >nul

:runtime_ready
echo [4/5] Updating application shell...
if exist "%SHELL%" rmdir /s /q "%SHELL%"
mkdir "%SHELL%"
xcopy "%~dp0shell" "%SHELL%\" /E /I /Y >nul
copy /Y "%~dp0RIFTSHIFT.ico" "%ROOT%\RIFTSHIFT.ico" >nul 2>nul

echo [5/5] Creating Desktop shortcut...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CREATE_SHORTCUT.ps1" ^
 -Exe "%RUNTIME%\RIFTSHIFT.exe" -WorkingDir "%RUNTIME%" -Icon "%ROOT%\RIFTSHIFT.ico"

echo.
echo Install complete.
echo.
echo IMPORTANT FOR AUTOMATIC UPDATES:
echo Run OPTIONAL_CHANGE_UPDATE_CHANNEL.bat once after you have a public update.json URL.
echo.
start "" "%RUNTIME%\RIFTSHIFT.exe"
exit /b 0

:download_failed
echo ERROR: Could not download Electron.
pause
exit /b 1

:extract_failed
echo ERROR: Could not extract Electron.
pause
exit /b 1
