const { app, BrowserWindow, Menu, ipcMain } = require("electron");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const net = require("net");

app.setName("RIFTSHIFT");
if(process.platform==="win32") app.setAppUserModelId("com.c0smic58.riftshift");

const SHELL_VERSION = "18.8.9";
let mainWindow = null;

function rootDir(){
  return path.resolve(path.dirname(process.execPath), "..");
}
function gameDir(){
  return path.join(rootDir(), "game");
}
function gamePath(){
  return path.join(gameDir(), "index.html");
}
function configPath(){
  return path.join(rootDir(), "update-config.json");
}
function installedVersion(){
  try{return fs.readFileSync(path.join(gameDir(),"version.txt"),"utf8").trim()||"0.0.0";}
  catch{return "0.0.0";}
}
function versionParts(v){
  return String(v||"0").replace(/^v/i,"").split(".").map(n=>parseInt(n,10)||0);
}
function newer(a,b){
  const A=versionParts(a),B=versionParts(b);
  for(let i=0;i<Math.max(A.length,B.length);i++){
    const x=A[i]||0,y=B[i]||0;
    if(x!==y)return x>y;
  }
  return false;
}
function readConfig(){
  const fallback={manifestUrl:"https://raw.githubusercontent.com/C0SMIC58/RIFTSHIFT/main/update.json"};
  try{
    const parsed=JSON.parse(fs.readFileSync(configPath(),"utf8"));
    if(!String(parsed.manifestUrl||"").trim())return fallback;
    return parsed;
  }catch{
    return fallback;
  }
}
async function downloadBuffer(url){
  const r=await fetch(url,{cache:"no-store"});
  if(!r.ok)throw new Error(`HTTP ${r.status} ${r.statusText}`);
  return Buffer.from(await r.arrayBuffer());
}
async function getManifest(){
  const cfg=readConfig();
  const url=String(cfg.manifestUrl||"").trim();
  if(!url)return {ok:false,reason:"not-configured"};
  const raw=await downloadBuffer(url);
  const manifest=JSON.parse(raw.toString("utf8"));
  if(!manifest.version||!manifest.gameUrl)throw new Error("Manifest needs version and gameUrl.");
  return {ok:true,manifest,url};
}
async function checkUpdate(){
  try{
    const result=await getManifest();
    if(!result.ok)return result;
    const m=result.manifest;
    return {
      ok:true,
      available:newer(m.version,installedVersion()),
      installedVersion:installedVersion(),
      version:String(m.version),
      gameUrl:String(m.gameUrl),
      sha256:String(m.sha256||"").toLowerCase(),
      notes:String(m.notes||""),
      overhaul:m.overhaul===true,
      priority:String(m.priority||"")
    };
  }catch(err){
    return {ok:false,reason:"error",message:err.message};
  }
}
async function installUpdate(info){
  try{
    if(!info||!info.gameUrl||!info.version)throw new Error("Update information is incomplete.");
    if(!newer(info.version,installedVersion()))return {ok:false,message:"That update is not newer than the installed game."};

    const data=await downloadBuffer(info.gameUrl);
    if(info.sha256){
      const hash=crypto.createHash("sha256").update(data).digest("hex").toLowerCase();
      if(hash!==String(info.sha256).toLowerCase())throw new Error("SHA-256 verification failed.");
    }

    fs.mkdirSync(gameDir(),{recursive:true});
    const tmp=path.join(gameDir(),"index.html.update");
    const backup=path.join(gameDir(),"index.html.previous");
    fs.writeFileSync(tmp,data);
    try{if(fs.existsSync(backup))fs.unlinkSync(backup);}catch{}
    try{if(fs.existsSync(gamePath()))fs.renameSync(gamePath(),backup);}catch{}
    fs.renameSync(tmp,gamePath());
    fs.writeFileSync(path.join(gameDir(),"version.txt"),String(info.version)+"\n");
    const nowInstalled=installedVersion();

    setTimeout(()=>{
      app.relaunch();
      app.exit(0);
    },500);
    return {ok:true,installedVersion:nowInstalled};
  }catch(err){
    return {ok:false,message:err.message};
  }
}

ipcMain.handle("riftshift:update-check",()=>checkUpdate());
ipcMain.handle("riftshift:update-install",(_event,info)=>installUpdate(info));

/* ============================================================
   Discord Rich Presence over local Discord RPC IPC.
   No authentication is required for basic direct Rich Presence,
   but Discord requires a valid registered Application ID.
   ============================================================ */
function discordConfigPath(){return path.join(rootDir(),"discord-config.json")}
function readDiscordConfig(){
  const fallback={applicationId:"",largeImageKey:"",largeImageText:"RIFTSHIFT",enabled:true};
  try{return {...fallback,...JSON.parse(fs.readFileSync(discordConfigPath(),"utf8"))}}catch{return fallback}
}
function validDiscordApplicationId(v){return /^\d{15,22}$/.test(String(v||"").trim())}
function discordFrame(op,payload){
  const body=Buffer.from(JSON.stringify(payload),"utf8"),head=Buffer.alloc(8);
  head.writeUInt32LE(op,0);head.writeUInt32LE(body.length,4);return Buffer.concat([head,body]);
}
class RiftshiftDiscordRPC{
  constructor(){this.socket=null;this.ready=false;this.connecting=false;this.buffer=Buffer.alloc(0);this.pending=null;this.retry=null;this.config=readDiscordConfig();this.lastSent="";}
  configured(){return this.config.enabled!==false&&validDiscordApplicationId(this.config.applicationId)}
  reload(){this.config=readDiscordConfig();return this.config}
  connect(){
    this.reload();if(!this.configured()||this.connecting||this.ready)return;
    this.connecting=true;let idx=0;
    const attempt=()=>{
      if(idx>9){this.connecting=false;this.scheduleRetry();return}
      const pipe=process.platform==="win32"?`\\\\?\\pipe\\discord-ipc-${idx}`:path.join(process.env.XDG_RUNTIME_DIR||process.env.TMPDIR||process.env.TMP||process.env.TEMP||"/tmp",`discord-ipc-${idx}`);
      const sock=net.createConnection(pipe);
      let settled=false;
      sock.once("connect",()=>{settled=true;this.attach(sock);this.socket=sock;this.connecting=false;sock.write(discordFrame(0,{v:1,client_id:String(this.config.applicationId)}))});
      sock.once("error",()=>{if(settled)return;settled=true;try{sock.destroy()}catch{}idx++;setTimeout(attempt,20)});
    };
    attempt();
  }
  attach(sock){
    sock.on("data",d=>this.onData(d));
    sock.on("error",()=>this.onDisconnect());
    sock.on("close",()=>this.onDisconnect());
  }
  onDisconnect(){this.ready=false;this.socket=null;this.buffer=Buffer.alloc(0);this.scheduleRetry()}
  scheduleRetry(){clearTimeout(this.retry);if(this.configured())this.retry=setTimeout(()=>this.connect(),8000)}
  onData(d){
    this.buffer=Buffer.concat([this.buffer,d]);
    while(this.buffer.length>=8){
      const op=this.buffer.readUInt32LE(0),len=this.buffer.readUInt32LE(4);if(this.buffer.length<8+len)return;
      const raw=this.buffer.subarray(8,8+len).toString("utf8");this.buffer=this.buffer.subarray(8+len);
      let data=null;try{data=JSON.parse(raw)}catch{}
      if(op===1&&data?.evt==="READY"){this.ready=true;if(this.pending)this.sendActivity(this.pending,true)}
      else if(op===3&&this.socket){this.socket.write(discordFrame(4,data||{}))}
      else if(op===2){this.onDisconnect()}
    }
  }
  sanitizeActivity(a){
    if(!a)return null;
    const cfg=this.config,activity={
      type:0,
      details:String(a.details||"Playing RIFTSHIFT").slice(0,128),
      state:String(a.state||"In the Rift").slice(0,128),
      timestamps:{start:Number(a.start)||Math.floor(Date.now()/1000)}
    };
    if(cfg.largeImageKey){
      activity.assets={large_image:String(cfg.largeImageKey).slice(0,128),large_text:String(a.largeText||cfg.largeImageText||"RIFTSHIFT").slice(0,128)};
      if(cfg.smallImageKey)activity.assets.small_image=String(cfg.smallImageKey).slice(0,128);
      if(cfg.smallImageText)activity.assets.small_text=String(cfg.smallImageText).slice(0,128);
    }
    return activity;
  }
  update(a){this.pending=this.sanitizeActivity(a);if(!this.configured())return false;if(!this.ready){this.connect();return false}return this.sendActivity(this.pending)}
  sendActivity(activity,force=false){
    if(!this.ready||!this.socket)return false;const sig=JSON.stringify(activity);if(!force&&sig===this.lastSent)return true;this.lastSent=sig;
    const payload={cmd:"SET_ACTIVITY",args:{pid:process.pid,activity},nonce:crypto.randomUUID()};
    try{this.socket.write(discordFrame(1,payload));return true}catch{this.onDisconnect();return false}
  }
  clear(){this.pending=null;this.lastSent="";if(this.ready&&this.socket){try{this.socket.write(discordFrame(1,{cmd:"SET_ACTIVITY",args:{pid:process.pid,activity:null},nonce:crypto.randomUUID()}))}catch{}}}
  status(){this.reload();return{configured:this.configured(),ready:this.ready,applicationId:this.configured()?String(this.config.applicationId):""}}
  shutdown(){this.clear();clearTimeout(this.retry);try{this.socket?.end()}catch{}}
}
const discordRPC=new RiftshiftDiscordRPC();
ipcMain.on("riftshift:discord-presence",(_event,a)=>discordRPC.update(a));
ipcMain.on("riftshift:discord-clear",()=>discordRPC.clear());
ipcMain.handle("riftshift:discord-status",()=>discordRPC.status());


function createWindow(){
  Menu.setApplicationMenu(null);
  if(!fs.existsSync(gamePath()))throw new Error("RIFTSHIFT game files are missing: "+gamePath());

  mainWindow=new BrowserWindow({
    title:"RIFTSHIFT",
    width:1440,
    height:900,
    minWidth:960,
    minHeight:620,
    backgroundColor:"#05070d",
    autoHideMenuBar:true,
    fullscreen:true,
    show:false,
    icon:path.join(__dirname,"RIFTSHIFT.ico"),
    webPreferences:{
      preload:path.join(__dirname,"preload.js"),
      contextIsolation:true,
      nodeIntegration:false,
      sandbox:false,
      backgroundThrottling:false
    }
  });

  discordRPC.connect();
  mainWindow.loadFile(gamePath());
  mainWindow.webContents.on("page-title-updated",event=>{event.preventDefault();mainWindow.setTitle("RIFTSHIFT");});
  mainWindow.webContents.on("did-finish-load",()=>mainWindow.setTitle("RIFTSHIFT"));
  mainWindow.once("ready-to-show",()=>{
    mainWindow.setFullScreen(true);
    mainWindow.show();
    mainWindow.focus();
  });

  mainWindow.webContents.on("before-input-event",(event,input)=>{
    if(input.type==="keyDown"&&input.key==="F11"){
      event.preventDefault();
      mainWindow.setFullScreen(!mainWindow.isFullScreen());
    }
  });
}

app.whenReady().then(createWindow);
app.on("activate",()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});
app.on("before-quit",()=>discordRPC.shutdown());
app.on("window-all-closed",()=>{if(process.platform!=="darwin")app.quit();});
