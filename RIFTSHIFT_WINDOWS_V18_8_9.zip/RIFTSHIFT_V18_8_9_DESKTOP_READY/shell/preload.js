const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("riftshiftUpdater", {
  check: () => ipcRenderer.invoke("riftshift:update-check"),
  install: (info) => ipcRenderer.invoke("riftshift:update-install", info)
});


contextBridge.exposeInMainWorld("riftshiftDiscord", {
  update: (activity) => ipcRenderer.send("riftshift:discord-presence", activity),
  clear: () => ipcRenderer.send("riftshift:discord-clear"),
  status: () => ipcRenderer.invoke("riftshift:discord-status")
});
