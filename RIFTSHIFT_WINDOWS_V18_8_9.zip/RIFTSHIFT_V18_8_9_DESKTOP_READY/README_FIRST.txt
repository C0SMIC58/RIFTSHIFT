RIFTSHIFT V18 — PRESENTATION / ANNOUNCER / DISCORD ACTIVITY

ANNOUNCER
- Priority queue: critical events can interrupt lower-priority lines.
- Dedicated top-center transmission UI with category labels and signal bars.
- Radio-style pre/post chirps layered around speech.
- Speech voice selection when the platform provides voices.
- Subtitle toggle.
- Voice toggle.
- Announcer volume slider.
- Duplicate suppression so repeated events do not spam.
- Critical / warning / standard visual styles.

ANNOUNCED EVENTS
- Wave milestones.
- Mini-boss arrivals.
- Boss arrivals.
- Boss Rage.
- Arena events.
- Rift Contract available / accepted / failed / completed.
- Rift Heat critical.
- Elite squad detection.
- Objective completion.
- Artifact installation.
- Perfect Dodge.
- Execution.
- Ultimate Evolution.
- Anomaly / secret boss messaging.
- Achievement notifications.
- Death / run telemetry transition.

POLISH
- Stacked contextual notifications replace single repetitive toast presentation.
- Damage frame pulse.
- Reactive crosshair bloom and low-energy indicator.
- Low-health synthetic heartbeat.
- Screen transition sweep.
- Better critical-event presentation.
- Discord status badge on desktop when configured.
- Existing V17 World/Arsenal systems remain.

DISCORD RICH PRESENCE
- Desktop application only.
- No npm package required; Electron shell talks directly to Discord's local RPC IPC.
- Presence can show menu state, class, wave, biome, difficulty, boss name, score/kills after a run, and elapsed run time.
- Requires your own Discord Application ID.
- Includes SETUP_DISCORD_ACTIVITY.bat and DISCORD_ACTIVITY_SETUP.txt.


RIFTSHIFT V18 — DISCORD GAME ACTIVITY SETUP

The V18 desktop build has Discord Rich Presence built into the Electron shell.
It does NOT need an npm package.

REQUIREMENTS
- Discord Desktop must be running and signed in.
- Discord Activity Sharing must be enabled in Discord.
- RIFTSHIFT needs its own Discord Application ID.

SETUP
1. Open the Discord Developer Portal:
   https://discord.com/developers/applications

2. Create a New Application.
   Name it:
   RIFTSHIFT

3. Copy the application's Application ID from the General Information page.

4. Run:
   SETUP_DISCORD_ACTIVITY.bat
   Paste the Application ID when asked.

5. Restart RIFTSHIFT and keep Discord Desktop open.

OPTIONAL LARGE ART
- In your Discord application's Rich Presence / Art Assets area, upload the RIFTSHIFT icon.
- Give the asset a key such as:
  riftshift_logo
- Run SETUP_DISCORD_ACTIVITY.bat again and enter that asset key when asked.
- If you leave the asset key blank, Rich Presence can still work, but without the custom large image.

WHAT RIFTSHIFT REPORTS
- Ship Terminal / menu
- Choosing an Operative
- Class
- Difficulty protocol
- Current Wave
- Current biome
- Boss being fought
- Anomaly Chamber
- Run-end wave / kills / score
- Elapsed run time

NOTES
- Browser builds cannot directly use Discord Desktop RPC; this integration is for the packaged desktop application.
- If Discord is closed when RIFTSHIFT starts, the game will retry periodically.
- Rich Presence only appears if Discord accepts your Application ID and the user's Discord Activity Sharing setting allows it.


V18.1 ANNOUNCER VOICE UPDATE
Use Settings -> SYSTEM VOICE and TEST VOICE to choose the best voice exposed by your PC.


RIFTSHIFT V18.2 — RIFTCORE VOX + ENGINE SPLASH

ANNOUNCER
- Default announcer is now RIFTCORE VOX.
- It uses 123 embedded pre-rendered voice clips and does NOT use Windows/Chromium TTS for normal supported announcements.
- Voice is consistent across browser and desktop builds.
- SYSTEM TTS remains selectable as an optional fallback.
- Main boss, mini-boss, contract, artifact, objective, achievement, wave milestone, event, execution, dodge, heat, anomaly and death lines are covered.
- Duplicate legacy V17 voice calls are suppressed.
- TEST VOICE now previews the currently selected voice engine.

STARTUP
- Pure black opening.
- Custom animated RIFTCORE ENGINE hex/rift mark assembles from traced geometry.
- Core ignition pulse and engine wordmark reveal.
- Engine runtime identification appears subtly under the mark.
- The engine animation intentionally reaches a visual settle point.
- RIFTSHIFT title then takes over as the handoff frame.
- Main menu is activated underneath the splash.
- Splash fades away over the live menu instead of hard-cutting.
- WebAudio permission no longer blocks the visual startup animation.
- Reduced-motion systems receive a shortened transition.

STATIC VALIDATION
- Browser JavaScript syntax checked.
- DOM ID references checked.


V18.8: warfront menu background, physical evolving weapons, muzzle-ground lighting, rebuilt enemies, full 2/3/4 class kits, and structural procedural maps.
