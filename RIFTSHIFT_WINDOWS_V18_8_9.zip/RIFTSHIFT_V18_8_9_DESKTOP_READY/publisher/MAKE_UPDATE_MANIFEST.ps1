param(
  [string]$Version = "8.0.0"
)
$ErrorActionPreference="Stop"
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$Game=Join-Path $Root "RIFTSHIFT_LATEST.html"

if (!(Test-Path $Game)) {
  Write-Host "Put your newest game file in this folder as RIFTSHIFT_LATEST.html" -ForegroundColor Yellow
  Read-Host "Press Enter"
  exit 1
}

$GameUrl="https://raw.githubusercontent.com/C0SMIC58/RIFTSHIFT/main/RIFTSHIFT_LATEST.html"
if ([string]::IsNullOrWhiteSpace($GameUrl)) { exit 1 }
$Notes=Read-Host "Short update notes"

$Hash=(Get-FileHash -Algorithm SHA256 $Game).Hash.ToLower()
$Manifest=[ordered]@{
  version=$Version
  gameUrl=$GameUrl
  sha256=$Hash
  notes=$Notes
}
$Manifest | ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $Root "update.json")

Write-Host ""
Write-Host "Created update.json" -ForegroundColor Green
Write-Host "Upload BOTH files to your public host:" -ForegroundColor Cyan
Write-Host "  RIFTSHIFT_LATEST.html"
Write-Host "  update.json"
Write-Host ""
Write-Host "Keep update.json at the SAME permanent URL every release." -ForegroundColor Cyan
