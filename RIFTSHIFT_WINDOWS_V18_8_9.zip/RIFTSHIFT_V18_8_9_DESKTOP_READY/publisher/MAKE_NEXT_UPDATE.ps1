param([Parameter(Mandatory=$true)][string]$Version,[string]$Notes="RIFTSHIFT update")
$ErrorActionPreference="Stop"
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$Game=Join-Path $Root "RIFTSHIFT_LATEST.html"
if(!(Test-Path $Game)){throw "Put the newest game in this folder as RIFTSHIFT_LATEST.html"}
$Hash=(Get-FileHash -Algorithm SHA256 $Game).Hash.ToLower()
$Manifest=[ordered]@{
 version=$Version
 gameUrl="https://raw.githubusercontent.com/C0SMIC58/RIFTSHIFT/main/RIFTSHIFT_LATEST.html"
 sha256=$Hash
 notes=$Notes
}
$Manifest|ConvertTo-Json|Set-Content -Encoding UTF8 (Join-Path $Root "update.json")
Write-Host "Generated update.json for V$Version" -ForegroundColor Cyan
Write-Host "Upload RIFTSHIFT_LATEST.html and update.json to the GitHub repo root." -ForegroundColor Green
