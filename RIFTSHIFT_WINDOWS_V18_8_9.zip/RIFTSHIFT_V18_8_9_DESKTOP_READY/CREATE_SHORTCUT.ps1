param(
 [Parameter(Mandatory=$true)][string]$Exe,
 [Parameter(Mandatory=$true)][string]$WorkingDir,
 [Parameter(Mandatory=$true)][string]$Icon
)
$ws=New-Object -ComObject WScript.Shell
$d=[Environment]::GetFolderPath("Desktop")
$l=$ws.CreateShortcut((Join-Path $d "RIFTSHIFT.lnk"))
$l.TargetPath=$Exe
$l.WorkingDirectory=$WorkingDir
$l.IconLocation="$Icon,0"
$l.Description="RIFTSHIFT"
$l.Save()
